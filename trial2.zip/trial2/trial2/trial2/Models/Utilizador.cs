﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace trial2.Models
{
    //[Table("Utilizador")]
    public class Utilizador
    {
        [Key]
        public string user_email { get; set; }
        public string nome { get; set; }
        public DateTime data_de_nascimento { get; set; }
        public string distrito { get; set; }
        public string rua { get; set; }
        public string localidade { get; set; }
        public string cc { get; set; }
        public string sexo { get; set; }
        public string contacto { get; set; }
        public List<Favoritos> favoritos { get; set; }
        /*public ICollection<Horario> horario_has_utilizador { get; set; }
        public ICollection<Canil> voluntario { get; set; }
        public ICollection<Adocao> adocao { get; set; }*/
    }


}
