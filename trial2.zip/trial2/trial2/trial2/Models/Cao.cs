﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace trial2.Models
{
    [Table("Cao")]
    public class Cao
    {
        [Key]
        public int idCao { get; set; }
        public string nome { get; set; }
        public string sexo { get; set; }
        public string descricao { get; set; }
        public int estado { get; set; }
        public string raca { get; set; }
        public string cor { get; set; }

        [ForeignKey("Canil")]
        public string canil_email { get; set; }
        public int idade { get; set; }
        public bool esterilizacao { get; set; }
        public string porte { get; set; }
        public ICollection<Favoritos> favoritos { get; set; }
    }
}
