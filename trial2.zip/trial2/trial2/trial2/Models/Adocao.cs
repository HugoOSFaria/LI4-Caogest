﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace trial2.Models
{
    public class Adocao
    {
        [Key]
        public int nPedido { get; set; }
        public DateTime data { get; set; }
        public int estado { get; set; }

        [ForeignKey("Utilizador")]
        public string utilizador_email { get; set; }

        [ForeignKey("Cao")]
        public int cao_idCao { get; set; }
        public int permissao { get; set; }
        public int alegria { get; set; }
        public string descAnimais { get; set; }
        public int ausencia { get; set; }
        public int habitacao { get; set; }
        public int exterior { get; set; }
        public int tipoMoradia { get; set; }
        public int motivo { get; set; }

        [ForeignKey("Fotografia")]
        public int fotografia_idFotografia { get; set; }
    }
}
