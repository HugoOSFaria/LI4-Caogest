﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using trial2.Models;

namespace trial2.Models
{
    public class trial2Context : DbContext
    {
        public trial2Context(DbContextOptions<trial2Context> options)
            : base(options)
        {
        }

        public DbSet<trial2.Models.Utilizador> Utilizador { get; set; }

        public DbSet<trial2.Models.Cao> Cao { get; set; }

        public DbSet<trial2.Models.Canil> Canil { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Horario>()
                .HasKey(h => new { h.dataInicio, h.dataFim});

            modelBuilder.Entity<Favoritos>(entity =>
            {
                entity.HasKey(f => new { f.utilizador_email, f.cao_idCao });

                entity.HasOne(f => f.utilizador)
                    .WithMany(c => c.favoritos)
                    .HasForeignKey(f => f.utilizador_email);

                entity.HasOne(f => f.cao)
                    .WithMany(u => u.favoritos)
                    .HasForeignKey(f => f.cao_idCao);

            });
        }

        public DbSet<trial2.Models.Favoritos> Favoritos { get; set; }

        public DbSet<trial2.Models.Adocao> Adocao { get; set; }

        public DbSet<trial2.Models.Fotografia> Fotografia { get; set; }

        public DbSet<trial2.Models.Horario> Horario { get; set; }

        public DbSet<trial2.Models.Parceria> Parceria { get; set; }
    }
}
