﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace trial2.Models
{
    [Table("Voluntarios")]
    public class Voluntarios
    {
        public string canil_email { get; set; }
        public string utilizador_email { get; set; }
    }
}
