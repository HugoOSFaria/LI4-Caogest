﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace trial2.Results
{
    public class ReceiveVoluntario
    {
        public string nomeCanil { get; set; }
        public string nomeUser { get; set; }
        public string mailUser { get; set; }
        public string contacto { get; set; }
        public string sexo { get; set; }
        public DateTime data_de_nascimento { get; set; }
    }
}
