﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using trial2.Models;

namespace trial2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CaesController : ControllerBase
    {
        private readonly trial2Context _context;

        public CaesController(trial2Context context)
        {
            _context = context;
        }

        // GET: api/Caes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cao>>> GetCao()
        {
            return await _context.Cao.ToListAsync();
        }

        // GET: api/Caes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Cao>> GetCao(int id)
        {
            var cao = await (from ca in _context.Cao
                             where ca.idCao == id
                             select ca).FirstOrDefaultAsync();

            if (cao == null)
            {
                return NotFound();
            }

            return cao;
        }

        // PUT: api/Caes/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCao(int id, Cao cao)
        {
            if (id != cao.idCao)
            {
                return BadRequest();
            }

            _context.Entry(cao).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CaoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Caes
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Cao>> PostCao(Cao cao)
        {
            _context.Cao.Add(cao);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCao", new { id = cao.idCao }, cao);
        }

        // DELETE: api/Caes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Cao>> DeleteCao(int id)
        {
            var cao = await _context.Cao.FindAsync(id);
            if (cao == null)
            {
                return NotFound();
            }

            _context.Cao.Remove(cao);
            await _context.SaveChangesAsync();

            return cao;
        }

        private bool CaoExists(int id)
        {
            return _context.Cao.Any(e => e.idCao == id);
        }
    }
}
