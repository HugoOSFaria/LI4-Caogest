﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using trial2.Models;

namespace trial2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VoluntariosController : ControllerBase
    {
        private readonly trial2Context _context;

        public VoluntariosController(trial2Context context)
        {
            _context = context;
        }

        // GET: api/Voluntarios
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Voluntarios>>> GetVoluntarios()
        {
            return await _context.Voluntarios.ToListAsync();
        }

        // GET: api/Voluntarios/5
        [HttpGet("{id}")]
        public async Task<ActionResult<List<Utilizador>>> GetVoluntarios(string id)
        {
            var voluntarios = await (from us in _context.Voluntarios
                                     join c in _context.Utilizador on us.utilizador_user_email equals c.user_email
                                     where us.canil_user_email == id
                                     select c).ToListAsync();

            if (voluntarios == null)
            {
                return NotFound();
            }

            return voluntarios;
        }

        // PUT: api/Voluntarios/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutVoluntarios(string id, Voluntarios voluntarios)
        {
            if (id != voluntarios.canil_user_email)
            {
                return BadRequest();
            }

            _context.Entry(voluntarios).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VoluntariosExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Voluntarios
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Voluntarios>> PostVoluntarios(Voluntarios voluntarios)
        {
            _context.Voluntarios.Add(voluntarios);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (VoluntariosExists(voluntarios.canil_user_email))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetVoluntarios", new { id = voluntarios.canil_user_email }, voluntarios);
        }

        // DELETE: api/Voluntarios/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Voluntarios>> DeleteVoluntarios(string id)
        {
            var voluntarios = await _context.Voluntarios.FindAsync(id);
            if (voluntarios == null)
            {
                return NotFound();
            }

            _context.Voluntarios.Remove(voluntarios);
            await _context.SaveChangesAsync();

            return voluntarios;
        }

        private bool VoluntariosExists(string id)
        {
            return _context.Voluntarios.Any(e => e.canil_user_email == id);
        }
    }
}
