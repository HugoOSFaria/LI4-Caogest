﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace trial2.Models
{
    public class Sugestoes
    {
        [Key]
        public int id { get; set; }
        [ForeignKey("Administrador")]
        public string adimistrador_user_email { get; set; }
        public string sugestoes { get; set; }
    }
}
