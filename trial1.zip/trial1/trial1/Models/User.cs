﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace trial1
{
    [Table("Utilizador")]
    public class User
    {
        [Key] 
        public string email { get; set; }
        public string nome { get; set; }
        public string password { get; set; }
        public DateTime data_nascimento { get; set; }
        public string distrito { get; set; }
        public string localidade { get; set; }
        public string rua { get; set; }
        public string cc { get; set; }
        //private List<Cao> favoritos { get; set; }
        //private DateTime horario_inicio { get; set; }
        //private DateTime horario_fim { get; set; }
        //private char voluntario { get; set; }
        internal AppDb Db { get; set; }

        public User()
        {
        }

        internal User(AppDb db)
        {
            Db = db;
        }

        public async Task InsertAsync()
        {
            using var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = "INSERT INTO 'Utilizador' (Email,Nome,Password,Data_de_Nascimento,Distrito,Rua,Localidade,CC) VALUES (@email, @nome, @password, @nasc, @distrito, @rua, @localidade, @cc)";
            BindParams(cmd);
            await cmd.ExecuteNonQueryAsync();
            email = cmd.LastInsertedId.ToString();
        }

        public async Task UpdateAsyncP()
        {
            using var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = "UPDATE `Utilizador` SET `Password` = @password WHERE `Email` = @email;";
            BindParams(cmd);
            BindEmail(cmd);
            await cmd.ExecuteNonQueryAsync();
        }

        /*public async Task UpdateAsync()
        {
            using var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = "UPDATE `Utilizador` SET `Title` = @title, `Content` = @content WHERE `Id` = @id;";
            BindParams(cmd);
            BindId(cmd);
            await cmd.ExecuteNonQueryAsync();
        }*/

        public async Task DeleteAsync()
        {
            using var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = @"DELETE FROM `Utilizador` WHERE `Email` = @email;";
            BindEmail(cmd);
            await cmd.ExecuteNonQueryAsync();
        }

        private void BindEmail(MySqlCommand cmd)
        {
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@email",
                DbType = DbType.String,
                Value = email,
            });
        }

        private void BindParams(MySqlCommand cmd)
        {
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@nome",
                DbType = DbType.String,
                Value = nome,
            });
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@password",
                DbType = DbType.String,
                Value = password,
            });
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@Data_de_Nascimento",
                DbType = DbType.String,
                Value = data_nascimento,
            });
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@Distrito",
                DbType = DbType.String,
                Value = distrito,
            });
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@Rua",
                DbType = DbType.String,
                Value = rua,
            });
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@Localidade",
                DbType = DbType.String,
                Value = localidade,
            });
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@CC",
                DbType = DbType.String,
                Value = cc,
            });
        }
    }
}
