﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using trial1;

namespace trial1.Data
{
    public class trial1Context : DbContext
    {
        public trial1Context (DbContextOptions<trial1Context> options)
            : base(options)
        {
        }

        public DbSet<trial1.User> User { get; set; }
    }
}
