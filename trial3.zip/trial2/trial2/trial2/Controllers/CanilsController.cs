﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using trial2.Models;

namespace trial2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CanilsController : ControllerBase
    {
        private readonly trial2Context _context;

        public CanilsController(trial2Context context)
        {
            _context = context;
        }

        // GET: api/Canils
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Canil>>> GetCanil()
        {
            return await _context.Canil.ToListAsync();
        }

        // GET: api/Canils/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Canil>> GetCanil(string id)
        {
            var canil = await _context.Canil.FindAsync(id);

            if (canil == null)
            {
                return NotFound();
            }

            canil.password = Encriptar.Desencriptacao(canil.password, "abc123");
            canil.localidade = Encriptar.Desencriptacao(canil.localidade, "abc123");
            canil.rua = Encriptar.Desencriptacao(canil.rua, "abc123");
            canil.distrito = Encriptar.Desencriptacao(canil.distrito, "abc123");
            canil.nib = Encriptar.Desencriptacao(canil.nib, "abc123");
            canil.nome = Encriptar.Desencriptacao(canil.nome, "abc123");
            canil.contacto = Encriptar.Desencriptacao(canil.contacto, "abc123");

            return canil;
        }

        // PUT: api/Canils/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCanil(string id, Canil canil)
        {
            if (id != canil.email)
            {
                return BadRequest();
            }

            canil.password = Encriptar.Encriptacao(canil.password, "abc123");
            canil.localidade = Encriptar.Encriptacao(canil.localidade, "abc123");
            canil.rua = Encriptar.Encriptacao(canil.rua, "abc123");
            canil.distrito = Encriptar.Encriptacao(canil.distrito, "abc123");
            canil.nib = Encriptar.Encriptacao(canil.nib, "abc123");
            canil.nome = Encriptar.Encriptacao(canil.nome, "abc123");
            canil.contacto = Encriptar.Encriptacao(canil.contacto, "abc123");

            _context.Entry(canil).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CanilExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Canils
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Canil>> PostCanil(Canil canil)
        {

            canil.password = Encriptar.Encriptacao(canil.password, "abc123");
            canil.localidade = Encriptar.Encriptacao(canil.localidade, "abc123");
            canil.rua = Encriptar.Encriptacao(canil.rua, "abc123");
            canil.distrito = Encriptar.Encriptacao(canil.distrito, "abc123");
            canil.nib = Encriptar.Encriptacao(canil.nib, "abc123");
            canil.nome = Encriptar.Encriptacao(canil.nome, "abc123");
            canil.contacto = Encriptar.Encriptacao(canil.contacto, "abc123");

            _context.Canil.Add(canil);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (CanilExists(canil.email))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetCanil", new { id = canil.email }, canil);
        }

        // DELETE: api/Canils/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Canil>> DeleteCanil(string id)
        {
            var canil = await _context.Canil.FindAsync(id);
            if (canil == null)
            {
                return NotFound();
            }

            _context.Canil.Remove(canil);
            await _context.SaveChangesAsync();

            return canil;
        }

        private bool CanilExists(string id)
        {
            return _context.Canil.Any(e => e.email == id);
        }
    }
}
