﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using trial2.Models;

namespace trial2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CanisController : ControllerBase
    {
        private readonly trial2Context _context;

        public CanisController(trial2Context context)
        {
            _context = context;
        }

        // GET: api/Canis
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Canil>>> GetCanil()
        {
            return await _context.Canil.ToListAsync();
        }

        // GET: api/Canis/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Canil>> GetCanil(string id)
        {
            var canil = await _context.Canil.Where(c => c.email == id).FirstOrDefaultAsync();

            if (canil == null)
            {
                return NotFound();
            }

            canil.password = Encriptar.Decrypt(canil.password);
            canil.localidade = Encriptar.Decrypt(canil.localidade);
            canil.rua = Encriptar.Decrypt(canil.rua);
            canil.distrito = Encriptar.Decrypt(canil.distrito);
            canil.nib = Encriptar.Decrypt(canil.nib);
            canil.nome = Encriptar.Decrypt(canil.nome);
            canil.contacto = Encriptar.Decrypt(canil.contacto);

            return canil;
        }

        // PUT: api/Canis/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCanil(string id, Canil canil)
        {
            if (id != canil.email)
            {
                return BadRequest();
            }

            canil.password = Encriptar.Encrypt(canil.password);
            canil.localidade = Encriptar.Encrypt(canil.localidade);
            canil.rua = Encriptar.Encrypt(canil.rua);
            canil.distrito = Encriptar.Encrypt(canil.distrito);
            canil.nib = Encriptar.Encrypt(canil.nib);
            canil.nome = Encriptar.Encrypt(canil.nome);
            canil.contacto = Encriptar.Encrypt(canil.contacto);


            _context.Entry(canil).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CanilExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Canis
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Canil>> PostCanil(Canil canil)
        {

            canil.password = Encriptar.Encrypt(canil.password);
            canil.localidade = Encriptar.Encrypt(canil.localidade);
            canil.rua = Encriptar.Encrypt(canil.rua);
            canil.distrito = Encriptar.Encrypt(canil.distrito);
            canil.nib = Encriptar.Encrypt(canil.nib);
            canil.nome = Encriptar.Encrypt(canil.nome);
            canil.contacto = Encriptar.Encrypt(canil.contacto);

            _context.Canil.Add(canil);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (CanilExists(canil.email))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetCanil", new { id = canil.email }, canil);
        }

        // DELETE: api/Canis/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Canil>> DeleteCanil(string id)
        {
            var canil = await _context.Canil.FindAsync(id);
            if (canil == null)
            {
                return NotFound();
            }

            _context.Canil.Remove(canil);
            await _context.SaveChangesAsync();

            return canil;
        }

        private bool CanilExists(string id)
        {

            return _context.Canil.Any(e => e.email == id);
        }
    }
}
