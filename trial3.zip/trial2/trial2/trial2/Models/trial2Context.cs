﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using trial2.Models;

namespace trial2.Models
{
    public class trial2Context : DbContext
    {
        public trial2Context(DbContextOptions<trial2Context> options)
            : base(options)
        {
        }

        public DbSet<trial2.Models.Utilizador> Utilizador { get; set; }

        public DbSet<trial2.Models.Cao> Cao { get; set; }

        public DbSet<trial2.Models.Canil> Canil { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<trial2.Models.Horario>()
                .HasKey(h => new { h.dataInicio, h.dataFim});
        }
    }
}
