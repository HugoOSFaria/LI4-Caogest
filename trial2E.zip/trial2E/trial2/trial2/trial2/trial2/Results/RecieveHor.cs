﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace trial2.Results
{
    public class RecieveHor
    {
        public string dataInicio { get; set; }
        public string dataFim { get; set; }
        public int capacidade { get; set; }
        public string canil_user_email { get; set; }
    }
}
