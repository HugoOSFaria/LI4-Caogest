﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using trial2.Models;
using trial2.Results;

namespace trial2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilizadorsController : ControllerBase
    {
        private readonly trial2Context _context;

        public UtilizadorsController(trial2Context context)
        {
            _context = context;
        }

        // GET: api/Utilizadors
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Utilizador>>> GetUtilizador()
        {
            return await _context.Utilizador.ToListAsync();
        }

        // GET: api/Utilizadors/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Utilizador>> GetUtilizador(string id)
        {
            var utilizador = await (from us in _context.Utilizador
                                    where us.user_email == id
                                    select us).FirstOrDefaultAsync();

            if (utilizador == null)
            {
                return NotFound();
            }

            utilizador.localidade = Encriptar.Decrypt(utilizador.localidade, "123abc");
            utilizador.rua = Encriptar.Decrypt(utilizador.rua, "1a2b3c");
            utilizador.distrito = Encriptar.Decrypt(utilizador.distrito, "cba321");
            utilizador.cc = Encriptar.Decrypt(utilizador.cc, "b32a1c");
            utilizador.nome = Encriptar.Decrypt(utilizador.nome, "1c2b3a");

            return utilizador;
        }

        // PUT: api/Utilizadors/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUtilizador(string id, Utilizador utilizador)
        {
            if (id != utilizador.user_email)
            {
                return BadRequest();
            }

            utilizador.localidade = Encriptar.Encrypt(utilizador.localidade, "123abc");
            utilizador.rua = Encriptar.Encrypt(utilizador.rua, "1a2b3c");
            utilizador.distrito = Encriptar.Encrypt(utilizador.distrito, "cba321");
            utilizador.cc = Encriptar.Encrypt(utilizador.cc, "b32a1c");
            utilizador.nome = Encriptar.Encrypt(utilizador.nome, "1c2b3a");

            _context.Entry(utilizador).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UtilizadorExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Utilizadors
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Utilizador>> PostUtilizador([FromBody] Utilizador utilizador)
        {

            utilizador.localidade = Encriptar.Encrypt(utilizador.localidade, "123abc");
            utilizador.rua = Encriptar.Encrypt(utilizador.rua, "1a2b3c");
            utilizador.distrito = Encriptar.Encrypt(utilizador.distrito, "cba321");
            utilizador.cc = Encriptar.Encrypt(utilizador.cc, "b32a1c");
            utilizador.nome = Encriptar.Encrypt(utilizador.nome, "1c2b3a");

            _context.Utilizador.Add(utilizador);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (UtilizadorExists(utilizador.user_email))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction(nameof(GetUtilizador), new { id = utilizador.user_email }, utilizador);
        }

        // DELETE: api/Utilizadors/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Utilizador>> DeleteUtilizador(string id)
        {
            var utilizador = await _context.Utilizador.FindAsync(id);
            if (utilizador == null)
            {
                return NotFound();
            }

            _context.Utilizador.Remove(utilizador);
            await _context.SaveChangesAsync();

            return utilizador;
        }

        private bool UtilizadorExists(string id)
        {
            return _context.Utilizador.Any(e => e.user_email == id);
        }
    }
}
